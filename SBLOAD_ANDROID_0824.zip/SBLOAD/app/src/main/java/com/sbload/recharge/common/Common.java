package com.sbload.recharge.common;

import android.app.Activity;
import android.graphics.Point;
import android.view.Display;

public class Common {

    public static Point screenSize(Activity context) {
        Point size = new Point();
        Display display = context.getWindowManager().getDefaultDisplay();
        display.getSize(size);
        return size;
    }
}
