package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.signup.SignUpRequest;
import com.sbload.recharge.utility.APIUtility;
import com.sbload.recharge.utility.StringUtility;

public class SignUpExecutive extends CommonExecutive {
    SignUpDisplay display;

    public SignUpExecutive(SignUpDisplay display) {
        super(display);
        this.display = display;
    }

    public void signUp() {
        SignUpRequest request = display.getSignUpRequest();
        if (request == null) {
            return;
        }

        int validateString = validateSignUpRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.showSuccess(R.string.signup_success);
                display.onSuccessSignUp();
            }
        }, this);
    }

    public int validateSignUpRequest(SignUpRequest request) {
        if (request.getName().isEmpty()) {
            return R.string.empty_user_name;
        }
        if (request.getEmail().isEmpty()) {
            return R.string.empty_email;
        }
        if (!StringUtility.isValidEmail(request.getEmail())) {
            return R.string.invalid_email;
        }
        if (request.getMobile().isEmpty()) {
            return R.string.empty_phone;
        }

        return R.string.input_validate;
    }

    public interface SignUpDisplay extends CommonExecutive.CommonDisplay {
        public void onSuccessSignUp();
        public SignUpRequest getSignUpRequest();
    }
}
