package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.view.BaseFragment;
import com.sbload.recharge.view.main.DashboardFragment;

public class RequestSuccessFragment extends BaseFragment implements View.OnClickListener {
    public RequestSuccessFragment() {
    }

    @Override
    public String getTagName() {
        return RequestSuccessFragment.class.getCanonicalName();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_request_success, container, false);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_redirect_to_dashboard).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_redirect_to_dashboard:
                popToFragment(DashboardFragment.class.getCanonicalName());
                break;
        }
    }
}
