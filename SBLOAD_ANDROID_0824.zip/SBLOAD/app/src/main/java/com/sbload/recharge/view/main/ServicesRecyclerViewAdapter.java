package com.sbload.recharge.view.main;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.utility.CommonUtility;

import java.util.ArrayList;

public class ServicesRecyclerViewAdapter extends RecyclerView.Adapter<ServicesRecyclerViewAdapter.ViewHolder> {

    private ArrayList<DashboardItem> services = new ArrayList<>();
    ServiceRecyclerItemEventListener listener;
    private Context context;
    public ServicesRecyclerViewAdapter(Context context, ServiceRecyclerItemEventListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setServices(ArrayList<DashboardItem> services) {
        this.services = services;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_service, parent, false);
        return new ServicesRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final DashboardItem dashboardItem = services.get(position);
        holder.serviceTextView.setText(dashboardItem.getName());
        Drawable drawable = CommonUtility.serviceDrawableFromAssets(context, dashboardItem.getSpaceuri());
        if (drawable != null) {
            holder.serviceImageView.setImageDrawable(drawable);
        }

        holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.didClickServiceItem(dashboardItem, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return services.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatImageView serviceImageView;
        final AppCompatTextView serviceTextView;
        View root;

        ViewHolder(View view) {
            super(view);

            root = view;
            serviceImageView = (AppCompatImageView) view.findViewById(R.id.img_service);
            serviceTextView = (AppCompatTextView) view.findViewById(R.id.text_view_service);
        }
    }

    public interface ServiceRecyclerItemEventListener {
        void didClickServiceItem(DashboardItem service, int position);
    }
}
