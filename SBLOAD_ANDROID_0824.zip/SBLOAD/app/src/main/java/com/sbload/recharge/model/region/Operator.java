package com.sbload.recharge.model.region;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Operator {
    @SerializedName("id")
    @Expose
    private int operatorId;

    @SerializedName("country")
    @Expose
    private int countryId;

    @SerializedName("code")
    @Expose
    private String code;

    @SerializedName("title")
    @Expose
    private String title;

    @SerializedName("length")
    @Expose
    private int length;

    @SerializedName("status")
    @Expose
    private int status;

    public int getOperatorId() {
        return operatorId;
    }

    public int getCountryId() {
        return countryId;
    }

    public String getTitle() {
        return title;
    }
}
