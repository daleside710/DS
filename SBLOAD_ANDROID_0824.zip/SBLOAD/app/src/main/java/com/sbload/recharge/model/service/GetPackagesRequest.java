package com.sbload.recharge.model.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.model.region.GetOperatorsResponse;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetPackagesRequest extends BaseRequest {

    private int operatorId;

    public GetPackagesRequest(int operatorId) {
        this.operatorId = operatorId;
    }

    public void post(final APIUtility.APIResponse<GetPackagesResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.getPackages(operatorId).enqueue(new Callback<GetPackagesResponse>() {
            @Override
            public void onResponse(Call<GetPackagesResponse> call, Response<GetPackagesResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<GetPackagesResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
