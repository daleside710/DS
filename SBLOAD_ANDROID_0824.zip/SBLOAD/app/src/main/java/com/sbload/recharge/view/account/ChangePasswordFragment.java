package com.sbload.recharge.view.account;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.account.ChangePasswordExecutive;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.model.account.changepassword.ChangePasswordRequest;
import com.sbload.recharge.view.BaseFragment;

public class ChangePasswordFragment extends BaseFragment implements View.OnClickListener, ChangePasswordExecutive.ChangePasswordDisplay {

    private AppCompatEditText editName, editPassword, editNewPassword;
    private ChangePasswordExecutive executive;

    final int ACTION_GO_TO_LOGIN = 1;
    final int SPLASH_DELAY_TIME = 2500;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == ACTION_GO_TO_LOGIN) {
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.LogOut);
            }
        }
    };

    public ChangePasswordFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_change_password, container, false);

        //
        // Bind Controls
        //

        editName = view.findViewById(R.id.edit_name);
        editPassword = view.findViewById(R.id.edit_password);
        editNewPassword = view.findViewById(R.id.edit_new_password);

        //
        // Bind Events
        //

        view.findViewById(R.id.btn_submit).setOnClickListener(this);
        view.findViewById(R.id.btn_side_menu).setOnClickListener(this);

        executive = new ChangePasswordExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_side_menu:
                containerExecutive.didPressSideMenuButton();
                break;
            case R.id.btn_submit:
                executive.changePassword();
        }
    }

    @Override
    public void passwordChanged() {
        mHandler.sendEmptyMessageDelayed(ACTION_GO_TO_LOGIN, SPLASH_DELAY_TIME);
    }

    @Override
    public ChangePasswordRequest getForgotPasswordRequest() {
        return new ChangePasswordRequest(editName.getText().toString(),
                editPassword.getText().toString(),
                editNewPassword.getText().toString());
    }
}
