package com.sbload.recharge.model.region;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetCountriesRequest extends BaseRequest {

    public GetCountriesRequest() {
    }

    public void post(final APIUtility.APIResponse<GetCountriesResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.getCountries(AppData.user.getUserId()).enqueue(new Callback<GetCountriesResponse>() {
            @Override
            public void onResponse(Call<GetCountriesResponse> call, Response<GetCountriesResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<GetCountriesResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
