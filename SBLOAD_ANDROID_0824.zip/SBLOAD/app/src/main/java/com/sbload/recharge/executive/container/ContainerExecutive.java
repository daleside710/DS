package com.sbload.recharge.executive.container;

import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.Service;

public class ContainerExecutive extends CommonExecutive {
    ContainerDisplay display;

    private SideMenuItem selectedItem = SideMenuItem.Home;

    public ContainerExecutive(ContainerDisplay display) {
        super(display);
        this.display = display;
    }

    public void showLoading(boolean isShow) {
        display.showLoading(isShow);
    }

    public void didPressSideMenuItem(SideMenuItem item) {
        if (selectedItem == item) {
            return;
        }
        selectedItem = item;
        display.selectSideMenuItem(item);
    }

    public void didPressSideMenuButton() {
        display.showSideMenu();
    }

    public void didPressDashboardButton(DashboardButton dashboardButton, String jsonSerialized) {
        display.didPressDashboardButton(dashboardButton, jsonSerialized);
    }

    public void didPressDashboardButton(DashboardItem dashboardItem) {
        if (dashboardItem instanceof Service) {
            display.didPressServiceItem((Service)dashboardItem);
            return;
        }

        display.didPressDashboardItem(dashboardItem);
    }

    public enum DashboardButton {
        AddReseller,
        EditReseller,
        ResellersList
    }

    public enum SideMenuItem {
        Home,
        AddPayments,
        ChangePassword,
        ChangePIN,
        OpenTickets,
        AboutUs,
        LogOut
    }

    public interface ContainerDisplay extends CommonExecutive.CommonDisplay {
        void selectSideMenuItem(SideMenuItem item);
        void didPressDashboardButton(DashboardButton dashboardButton, String jsonSerialized);
        void didPressServiceItem(Service service);
        void didPressDashboardItem(DashboardItem dashboardItem);
        void showSideMenu();
    }
}
