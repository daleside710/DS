package com.sbload.recharge.executive.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.GetCountriesRequest;
import com.sbload.recharge.model.region.GetCountriesResponse;
import com.sbload.recharge.model.region.GetOperatorsRequest;
import com.sbload.recharge.model.region.GetOperatorsResponse;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class PackageRequestExecutive extends CommonExecutive {
    PackageRequestDisplay display;
    ArrayList<Country> countries = new ArrayList<>();
    ArrayList<Operator> operators = new ArrayList<>();

    public PackageRequestExecutive(PackageRequestDisplay display) {
        super(display);
        this.display = display;
    }

    public interface PackageRequestDisplay extends CommonExecutive.CommonDisplay {
        ServiceRequestRequest getServiceRequestRequest();
    }
}
