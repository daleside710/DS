package com.sbload.recharge.model.account.reseller;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.Reseller;

public class AddResellerResponse extends CommonResponse {

    @SerializedName("user")
    @Expose
    public Reseller reseller;

    public Reseller getReseller() {
        return reseller;
    }
}
