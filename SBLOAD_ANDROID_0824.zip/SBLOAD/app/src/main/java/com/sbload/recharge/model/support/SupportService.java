package com.sbload.recharge.model.support;

import com.sbload.recharge.model.CommonResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface SupportService {

    @FormUrlEncoded
    @POST("support/open_tickets")
    Call<CommonResponse> openTickets(@Field("user_id") String userId,
                                     @Field("subject") String subject,
                                     @Field("details") String details);
}
