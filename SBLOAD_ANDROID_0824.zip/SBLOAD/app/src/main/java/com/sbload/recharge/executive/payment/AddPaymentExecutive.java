package com.sbload.recharge.executive.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.account.reseller.GetResellersRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;
import com.sbload.recharge.model.payment.AddPaymentRequest;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.model.service.ServiceRequestResponse;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class AddPaymentExecutive extends CommonExecutive {
    AddPaymentDisplay display;
    ArrayList<Reseller> resellers = new ArrayList<>();

    public AddPaymentExecutive(AddPaymentDisplay display) {
        super(display);
        this.display = display;
    }

    public void getResellers() {
        GetResellersRequest request = new GetResellersRequest(AppData.user.getUserId());

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetResellersResponse>() {
            @Override
            public void onResponse(GetResellersResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                resellers = response.getResellers();
                display.onGetResellers(response.getResellers());
            }
        }, this);
    }

    public void didPressSubmit() {
        AddPaymentRequest paymentRequest = display.getAddPaymentRequest();
        int validateString = validateAddPaymentRequest(paymentRequest);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.gotoPaymentConfirm(paymentRequest, resellers);
    }

    public int validateAddPaymentRequest(AddPaymentRequest request) {
        if (request.getAmount() <= 0) {
            return R.string.invalid_amount;
        }

        return R.string.input_validate;
    }

    public interface AddPaymentDisplay extends CommonDisplay {
        void onGetResellers(ArrayList<Reseller> resellers);
        AddPaymentRequest getAddPaymentRequest();
        void gotoPaymentConfirm(AddPaymentRequest request, ArrayList<Reseller> resellers);
    }
}
