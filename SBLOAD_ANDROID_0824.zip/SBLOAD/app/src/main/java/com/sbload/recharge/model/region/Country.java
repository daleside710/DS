package com.sbload.recharge.model.region;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Country {
    @SerializedName("id")
    @Expose
    private int countryId;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("iso_alpha2")
    @Expose
    private String isoAlpha2;

    @SerializedName("iso_alpha3")
    @Expose
    private String isoAlpha3;

    @SerializedName("iso_numeric")
    @Expose
    private int isoNumberic;

    @SerializedName("currency_code")
    @Expose
    private String currencyCode;

    @SerializedName("currency_name")
    @Expose
    private String currencyName;

    @SerializedName("currency_symbol")
    @Expose
    private String currencySymbol;

    @SerializedName("flag")
    @Expose
    private String flag;

    @SerializedName("phonecode")
    @Expose
    private String phonecode;

    @SerializedName("status")
    @Expose
    private int status;

    public int getCountryId() {
        return countryId;
    }

    public String getName() {
        return name;
    }
}
