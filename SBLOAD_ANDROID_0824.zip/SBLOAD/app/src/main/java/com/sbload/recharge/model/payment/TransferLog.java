package com.sbload.recharge.model.payment;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TransferLog {
    @SerializedName("id")
    @Expose
    private Integer logId;

    @SerializedName("bal_from")
    @Expose
    private Integer balFrom;

    @SerializedName("bal_to")
    @Expose
    private Integer balTo;

    @SerializedName("amount")
    @Expose
    private Float amount;

    @SerializedName("actual")
    @Expose
    private Float actual;

    @SerializedName("type")
    @Expose
    private String type;

    @SerializedName("byadmin")
    @Expose
    private Integer byAdmin;

    @SerializedName("logtime")
    @Expose
    private String logTime;

    @SerializedName("note")
    @Expose
    private String note;

    public Float getActual() {
        return actual;
    }

    public String getLogTime() {
        return logTime;
    }

    public String getNote() {
        return note;
    }
}
