package com.sbload.recharge.model.service;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.model.region.GetCountriesResponse;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetPackageOperatorsRequest extends BaseRequest {

    public GetPackageOperatorsRequest() {
    }

    public void post(final APIUtility.APIResponse<GetPackageOperatorsResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.getPackageOperators("").enqueue(new Callback<GetPackageOperatorsResponse>() {
            @Override
            public void onResponse(Call<GetPackageOperatorsResponse> call, Response<GetPackageOperatorsResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<GetPackageOperatorsResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
