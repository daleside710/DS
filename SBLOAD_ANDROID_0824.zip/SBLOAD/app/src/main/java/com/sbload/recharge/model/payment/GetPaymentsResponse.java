package com.sbload.recharge.model.payment;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.service.ServiceRequest;

import java.util.ArrayList;

public class GetPaymentsResponse extends CommonResponse {

    @SerializedName("response")
    @Expose
    public ArrayList<TransferLog> transferLogs;

    public ArrayList<TransferLog> getTransferLogs() {
        return transferLogs;
    }
}
