package com.sbload.recharge.view.main;


import android.os.Bundle;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.account.AddResellerExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.account.reseller.AddResellerRequest;
import com.sbload.recharge.model.account.reseller.EditResellerRequest;
import com.sbload.recharge.model.account.reseller.ResellerChanged;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class AddResellerFragment extends BaseFragment implements View.OnClickListener, AddResellerExecutive.AddResellerDisplay {

    private static final String ARG_RESELLER = "arg_reseller";
    private AppCompatTextView titleTextView;
    private AppCompatEditText userNameEditText, passwordEditText, pinEditText;
    private AppCompatEditText newPasswordEditText, newPINEditText;
    private AppCompatEditText emailEditText, mobileEditText, noteEditText;
    private AppCompatCheckBox activeCheckBox;
    public Reseller reseller;
    public ArrayList<Service> services;
    public ResellerChanged resellerChangedInterface;
    private RecyclerView servicesCheckRecyclerView;
    private ServicesCheckRecyclerViewAdapter servicesCheckAdapter;
    private AddResellerExecutive executive;

    public AddResellerFragment() {
    }

    public static AddResellerFragment newInstance(String resellerSerialized) {
        AddResellerFragment fragment = new AddResellerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_RESELLER, resellerSerialized);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (reseller != null) {
            return;
        }
        if (getArguments() != null) {
            String resellerJson = getArguments().getString(ARG_RESELLER);
            reseller = new Gson().fromJson(resellerJson, Reseller.class);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_reseller, container, false);

        //
        // Bind controls
        //

        titleTextView = view.findViewById(R.id.txt_title);
        if (reseller == null) {
            titleTextView.setText(R.string.add_reseller);
        }
        else {
            titleTextView.setText(R.string.edit_reseller);
        }
        userNameEditText = view.findViewById(R.id.edit_username);
        emailEditText = view.findViewById(R.id.edit_email);
        passwordEditText = view.findViewById(R.id.edit_password);
        newPasswordEditText = view.findViewById(R.id.edit_new_password);
        newPasswordEditText.setVisibility(reseller == null ? View.GONE : View.VISIBLE);
        mobileEditText = view.findViewById(R.id.edit_mobile);
        pinEditText = view.findViewById(R.id.edit_pin);
        newPINEditText = view.findViewById(R.id.edit_new_pin);
        newPINEditText.setVisibility(reseller == null ? View.GONE : View.VISIBLE);
        noteEditText = view.findViewById(R.id.edit_note);
        activeCheckBox = view.findViewById(R.id.chk_active);
        if (reseller != null) {
            userNameEditText.setText(reseller.getUserName());
            mobileEditText.setText(reseller.getMobile());
            emailEditText.setText(reseller.getEmail());
            noteEditText.setText(reseller.getNote());
            activeCheckBox.setChecked(reseller.getStatus() == 1);
        }
        servicesCheckRecyclerView = view.findViewById(R.id.service_recycler);
        servicesCheckRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        servicesCheckAdapter = new ServicesCheckRecyclerViewAdapter(getActivity(), reseller);
        servicesCheckAdapter.setServices(services);
        servicesCheckRecyclerView.setAdapter(servicesCheckAdapter);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        view.findViewById(R.id.btn_submit).setOnClickListener(this);
        executive = new AddResellerExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_submit:
                if (reseller != null) {
                    executive.editReseller(services, servicesCheckAdapter.getCheckStates());
                }
                else {
                    executive.addReseller(services, servicesCheckAdapter.getCheckStates());
                }
                break;
        }
    }

    @Override
    public void onSuccessAddReseller() {
        popBackStack();
    }

    @Override
    public void onSuccessEditReseller() {
        popBackStack();
        resellerChangedInterface.resellerChanged();
    }

    @Override
    public AddResellerRequest getAddResellerRequest(int type) {
        return new AddResellerRequest(AppData.user.getUserId(), userNameEditText.getText().toString(),
                passwordEditText.getText().toString(), mobileEditText.getText().toString(),
                emailEditText.getText().toString(), noteEditText.getText().toString(),
                pinEditText.getText().toString(), type, activeCheckBox.isChecked() ? 1 : 0);
    }

    @Override
    public EditResellerRequest getEditResellerRequest(int type) {
        return new EditResellerRequest(reseller.getUserId(), userNameEditText.getText().toString(),
                passwordEditText.getText().toString(), newPasswordEditText.getText().toString(),
                mobileEditText.getText().toString(), emailEditText.getText().toString(),
                noteEditText.getText().toString(), pinEditText.getText().toString(),
                newPINEditText.getText().toString(), type, activeCheckBox.isChecked() ? 1 : 0);
    }
}
