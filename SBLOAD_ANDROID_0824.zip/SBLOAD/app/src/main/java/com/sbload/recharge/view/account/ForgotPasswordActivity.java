package com.sbload.recharge.view.account;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.account.ForgotPasswordExecutive;
import com.sbload.recharge.model.account.forgotpassword.ForgotPasswordRequest;
import com.sbload.recharge.view.BaseActivity;

public class ForgotPasswordActivity extends BaseActivity implements ForgotPasswordExecutive.ForgotPasswordDisplay {

    private ForgotPasswordExecutive executive;
    private AppCompatEditText editName;

    final int ACTION_GO_TO_LOGIN = 1;
    final int SPLASH_DELAY_TIME = 2500;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == ACTION_GO_TO_LOGIN) {
                finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        //
        // Bind Controls
        //

        editName = findViewById(R.id.edit_name);

        //
        // Bind events
        //

        findViewById(R.id.btn_reset_password).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executive.requestForgotPassword();
            }
        });

        executive = new ForgotPasswordExecutive(this);
    }

    @Override
    public void passwordReset() {
        mHandler.sendEmptyMessageDelayed(ACTION_GO_TO_LOGIN, SPLASH_DELAY_TIME);
    }

    @Override
    public ForgotPasswordRequest getForgotPasswordRequest() {
        return new ForgotPasswordRequest(editName.getText().toString());
    }
}
