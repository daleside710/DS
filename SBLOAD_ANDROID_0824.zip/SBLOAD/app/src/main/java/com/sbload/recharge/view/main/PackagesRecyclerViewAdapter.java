package com.sbload.recharge.view.main;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.ServicePackage;
import com.sbload.recharge.utility.CommonUtility;

import java.util.ArrayList;

public class PackagesRecyclerViewAdapter extends RecyclerView.Adapter<PackagesRecyclerViewAdapter.ViewHolder> {

    private ArrayList<ServicePackage> packages = new ArrayList<>();
    PackagesRecyclerItemEventListener listener;
    private Context context;
    public PackagesRecyclerViewAdapter(Context context, PackagesRecyclerItemEventListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setPackages(ArrayList<ServicePackage> packages) {
        this.packages = packages;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_package, parent, false);
        return new PackagesRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final ServicePackage servicePackage = packages.get(position);
        holder.packageNameTextView.setText(servicePackage.getTitle());
        holder.amountTextView.setText("Amount : " + (int)servicePackage.getAmount());

        holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.didClickPackageItem(servicePackage, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return packages.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatTextView packageNameTextView, amountTextView;
        View root;

        ViewHolder(View view) {
            super(view);

            root = view;
            packageNameTextView = view.findViewById(R.id.txt_package_name);
            amountTextView = view.findViewById(R.id.txt_amount);
        }
    }

    public interface PackagesRecyclerItemEventListener {
        void didClickPackageItem(ServicePackage service, int position);
    }
}
