package com.sbload.recharge.model.account.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.Reseller;

public class GetResellerResponse extends CommonResponse {

    @SerializedName("response")
    @Expose

    private Reseller reseller;

    public Reseller getReseller() {
        return reseller;
    }
}
