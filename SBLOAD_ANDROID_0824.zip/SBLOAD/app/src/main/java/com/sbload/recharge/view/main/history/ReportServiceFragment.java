package com.sbload.recharge.view.main.history;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.ReportExecutive;
import com.sbload.recharge.model.service.GetHistoriesRequest;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class ReportServiceFragment extends BaseFragment implements View.OnClickListener, ReportExecutive.ReportDisplay, ReportRecyclerViewAdapter.HistoryRecyclerItemEventListener {
    private RecyclerView historiesRecyclerView;
    private ReportRecyclerViewAdapter historiesAdapter;
    private ReportExecutive executive;

    public ReportServiceFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_report, container, false);

        historiesAdapter = new ReportRecyclerViewAdapter(getActivity(), this);

        //
        // Define controls
        //

        historiesRecyclerView = view.findViewById(R.id.recycler_history);
        historiesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        historiesRecyclerView.setAdapter(historiesAdapter);

        //
        // Set Event Handler
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);

        executive = new ReportExecutive(this);
        executive.requestGetHistories();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }

    @Override
    public void onGetHistories(ArrayList<ServiceRequest> histories) {
        historiesAdapter.setHistories(histories);
        historiesAdapter.notifyDataSetChanged();
    }

    @Override
    public GetHistoriesRequest getHistoriesRequest() {
        return new GetHistoriesRequest(AppData.user.getUserId(), "", "");
    }
}
