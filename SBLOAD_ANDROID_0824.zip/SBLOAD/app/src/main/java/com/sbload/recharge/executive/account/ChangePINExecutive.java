package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.pin.ChangePINRequest;
import com.sbload.recharge.utility.APIUtility;

public class ChangePINExecutive extends CommonExecutive {
    ChangePINDisplay display;

    public ChangePINExecutive(ChangePINDisplay display) {
        super(display);
        this.display = display;
    }

    public void changePIN() {
        ChangePINRequest request = display.getChangePINRequest();
        if (request == null) {
            return;
        }

        int validateString = validateChangePINRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.showSuccess(R.string.changed_pin_success);
                display.PINChanged();
            }
        }, this);
    }

    public int validateChangePINRequest(ChangePINRequest request) {
        if (request.getUserName().isEmpty()) {
            return R.string.empty_user_name;
        }

        if (request.getPassword().isEmpty()) {
            return R.string.empty_password;
        }

        if (request.getPin().isEmpty()) {
            return R.string.empty_pin;
        }

        if (request.getPin().length() != 6) {
            return R.string.invalid_pin;
        }

        return R.string.input_validate;
    }

    public interface ChangePINDisplay extends CommonExecutive.CommonDisplay {
        public void PINChanged();
        public ChangePINRequest getChangePINRequest();
    }
}
