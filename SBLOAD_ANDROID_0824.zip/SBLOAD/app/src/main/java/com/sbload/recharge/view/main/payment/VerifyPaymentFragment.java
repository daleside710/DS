package com.sbload.recharge.view.main.payment;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.common.Constants;
import com.sbload.recharge.executive.payment.VerifyPaymentExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.payment.AddPaymentRequest;
import com.sbload.recharge.view.BaseFragment;
import com.sbload.recharge.view.account.DomainActivity;
import com.sbload.recharge.view.account.LoginActivity;
import com.sbload.recharge.view.container.ContainerActivity;

import java.util.ArrayList;

public class VerifyPaymentFragment extends BaseFragment implements VerifyPaymentExecutive.VerifyPaymentDisplay, View.OnClickListener {

    public AddPaymentRequest request;
    public ArrayList<Reseller> resellers;

    final int ACTION_GO_TO_BACK = 1;
    final int DELAY_TIME = 1000;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == ACTION_GO_TO_BACK) {
                popBackStack();
            }
        }
    };

    private AppCompatEditText pinEditText;
    private AppCompatTextView resellerNameTextView, amountTextView, typeTextView;

    private VerifyPaymentExecutive executive;

    public VerifyPaymentFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_verify_payment, container, false);

        //
        // Bind Controls
        //

        resellerNameTextView = view.findViewById(R.id.txt_reseller_name);
        amountTextView = view.findViewById(R.id.txt_amount);
        typeTextView = view.findViewById(R.id.txt_type);
        pinEditText = view.findViewById(R.id.edit_pin);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_submit).setOnClickListener(this);

        executive = new VerifyPaymentExecutive(this);
        executive.displayDidLoad(request, resellers);
        return view;
    }

    @Override
    public AddPaymentRequest getAddPaymentRequest() {
        request.setPin(pinEditText.getText().toString());
        Reseller reseller = resellers.get(request.getToUserId());
        request.setToUserId(Integer.valueOf(reseller.getUserId()));
        return request;
    }

    @Override
    public void onSuccessProcessPayment() {
        mHandler.sendEmptyMessageDelayed(ACTION_GO_TO_BACK, DELAY_TIME);
        popBackStack();
    }

    @Override
    public void showConfirmations(String resellerName, String amount, String type) {
        resellerNameTextView.setText(resellerName);
        amountTextView.setText(amount);
        typeTextView.setText(type);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_submit:
                executive.didPressSubmit();
                break;
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }
}
